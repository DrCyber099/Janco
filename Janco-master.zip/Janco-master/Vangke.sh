clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
echo
echo
start.sh
echo
clear
echo
echo $me"                     ¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶"
echo $me"                 ¶¶¶¶¶¶             ¶¶¶¶¶¶¶"
echo $me"              ¶¶¶¶                        ¶¶¶¶"
echo $me"             ¶¶¶                            ¶¶¶"
echo $me"            ¶¶                                ¶¶"
echo $me"           ¶¶                                  ¶¶"
echo $me"          ¶¶                                   ¶¶"
echo $me"          ¶¶´¶¶                             ¶¶´¶¶"
echo $me"          ¶¶´¶¶                             ¶¶´´¶"
echo $me"          ¶¶´¶¶                             ¶¶´´¶"
echo $me"         ¶¶  ¶¶                            ¶¶´¶¶"
echo $me"          ¶¶´´¶¶                           ¶¶´´¶¶"
echo $me"           ¶¶´¶¶   ¶¶¶¶¶¶¶¶     ¶¶¶¶¶¶¶¶   ¶¶´¶¶"
echo $me"            ¶¶¶¶´¶¶¶¶¶¶¶¶¶¶     ¶¶¶¶¶¶¶¶¶¶ ¶¶¶¶¶"
echo $me"             ¶¶¶´¶¶¶¶¶¶¶¶¶¶     ¶¶¶¶¶¶¶¶¶¶ ¶¶¶"
echo $me"    ¶¶¶       ¶¶  ¶¶¶¶¶¶¶¶       ¶¶¶¶¶¶¶¶¶  ¶¶      ¶¶¶¶"
echo $me"   ¶¶¶¶¶     ¶¶   ¶¶¶¶¶¶¶   ¶¶¶   ¶¶¶¶¶¶¶   ¶¶     ¶¶¶¶¶¶"
echo $me"  ¶¶   ¶¶    ¶¶     ¶¶¶    ¶¶¶¶¶    ¶¶¶     ¶¶    ¶¶   ¶¶"
echo $me" ¶¶¶    ¶¶¶¶  ¶¶          ¶¶¶¶¶¶¶          ¶¶  ¶¶¶¶    ¶¶¶"
echo $me"¶¶         ¶¶¶¶¶¶¶¶       ¶¶¶¶¶¶¶        ¶¶¶¶¶¶¶¶¶        ¶¶"
echo $me"¶¶¶¶¶¶¶¶¶     ¶¶¶¶¶¶¶¶    ¶¶¶¶¶¶¶    ¶¶¶¶¶¶¶¶      ¶¶¶¶¶¶¶¶"
echo $me"  ¶¶¶¶ ¶¶¶¶¶      ¶¶¶¶¶              ¶¶¶ ¶¶     ¶¶¶¶¶¶ ¶¶¶"
echo $me"       ¶¶¶¶¶¶  ¶¶¶  ¶¶           ¶¶  ¶¶¶  ¶¶¶¶¶¶"
echo $me"              ¶¶¶¶¶¶ ¶¶ ¶¶¶¶¶¶¶¶¶¶¶ ¶¶ ¶¶¶¶¶¶"
echo $me"                  ¶¶ ¶¶ ¶ ¶ ¶ ¶ ¶ ¶ ¶ ¶ ¶¶"
echo $me"                ¶¶¶¶  ¶ ¶ ¶ ¶ ¶ ¶ ¶ ¶   ¶¶¶¶¶"
echo $me"            ¶¶¶¶¶ ¶¶   ¶¶¶¶¶¶¶¶¶¶¶¶¶   ¶¶ ¶¶¶¶¶"
echo $me"    ¶¶¶¶¶¶¶¶¶¶     ¶¶                 ¶¶      ¶¶¶¶¶¶¶¶¶"
echo $me"   ¶¶           ¶¶¶¶¶¶¶             ¶¶¶¶¶¶¶¶          ¶¶"
echo $me"    ¶¶¶     ¶¶¶¶¶     ¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶     ¶¶¶¶¶     ¶¶¶"
echo $me"      ¶¶   ¶¶¶           ¶¶¶¶¶¶¶¶¶           ¶¶¶   ¶¶"
echo $me"      ¶¶  ¶¶                                   ¶¶  ¶¶"
echo $me"       ¶¶¶¶                                     ¶¶¶¶"
echo
echo
echo $cy "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo $i  "NANA       : RANGGA HARSYA"
echo $i  "TEAM        : DR.CYBER"
echo $i  "WEBSITE  : termux.id"
echo $i  "Youtube    : Last Pro Editor"
echo $cy "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo
echo
echo "###DrCyber Rangga Harsya###"
echo
echo $cy "[1]"$bi" Bokep Indo"
echo "=================================================="
echo $cy "[2]"$i" Bokep japanes"
echo "=================================================="
echo $cy "[3]"$me" XNXX"
echo "=================================================="
echo $cy "[4]"$ku" SIMONTOK"
echo "=================================================="
echo $cy "[5]"$pur" Luna Maya"
echo "=================================================="
echo $cy "[6]"$pu" Natasya Wilona"
echo "=================================================="
echo $cy "[7]"$cy" WA l*nte"
echo "=================================================="
echo $cy "[8]"$me" EXIT"
echo "=================================================="
echo
echo
echo $cy"┌==="$bi"[ DR CYBER ]"
echo $cy"¦"
read -p">>>" pil;
if [ $pil = 1 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 2 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 3 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 4 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 5 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 6 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 7 ]
then
clear
sh Tobat.sh
fi
if [ $pil = 8 ]
then
clear
figlet -f slant "E X I T"|lolcat
sleep 2
echo $cy"Terima Kasih Sudah Pakai Tool Saya"
sleep 2
echo $i"Bila Ada Bug  Bisa Nanya Kepada Saya"
sleep 2
echo $i"WhatsApp :"$i" 0899999999999"
echo $bi"instagram :"$i" DrCyber099
exit
fi
